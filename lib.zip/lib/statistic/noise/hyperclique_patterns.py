from __future__ import division

class HypercliqueMiner(object):
    def __init__(self, hconf_thresh=0.55, supp_thresh=0.0, verbose=False):
        self._hconf_thresh = hconf_thresh
        self._supp_thresh = supp_thresh
        self._T = None
        self._I = None
        self._verbose = verbose

    def set_transections(self, transactions):
        self._T = [set(x) for x in transactions]
        self._I = set([i for x in transactions for i in x])
        if self._verbose:
            print('Total transactions {}, total items {}'.format(len(self._T), len(self._I)))

    def supp(self, pattern):
        assert self._T is not None
        assert self._I is not None
        assert type(pattern) is set and len(pattern) > 0
        return len([True for t in self._T if pattern.issubset(t)]) / float(len(self._T))

    def conf(self, pattern1, pattern2):
        assert self._T is not None
        assert self._I is not None
        assert type(pattern1) is set and len(pattern1) > 0
        assert type(pattern2) is set and len(pattern2) > 0
        return self.supp(pattern1.union(pattern2)) / self.supp(pattern1)

    def hconf(self, pattern):
        assert self._T is not None
        assert self._I is not None
        assert type(pattern) is set and len(pattern) > 0
        return self.supp(pattern) / max([self.supp({i}) for i in pattern])

    def _anti_monotonic(self, pattern):
        min_supp = min([self.supp({i}) for i in pattern])
        max_supp = max([self.supp({i}) for i in pattern])
        hconf_upper_bound = min_supp / max_supp
        return hconf_upper_bound

    def _cross_supp(self, pattern1, pattern2):
        max_supp = max([self.supp({i}) for i in pattern1])
        min_supp = min([self.supp({i}) for i in pattern2])
        hconf_upper_bound = max_supp / min_supp
        return hconf_upper_bound

    def _k_subsets(self, s, k):
        def k_subsets_i(n, k):
            if k == 0 or n < k:
                yield set()
            elif n == k:
                yield set(range(n))
            else:
                for s in k_subsets_i(n - 1, k - 1):
                    s.add(n - 1)
                    yield s
                for s in k_subsets_i(n - 1, k):
                    yield s
        s = list(s)
        n = len(s)
        for k_set in k_subsets_i(n, k):
            yield set([s[i] for i in k_set])

    def gen_candidate(self, prevalent_patterns):
        candidate = []
        already_gen = set()
        for i in range(0, len(prevalent_patterns)):
            for j in range(i+1, len(prevalent_patterns)):
                pattern1 = prevalent_patterns[i]
                pattern2 = prevalent_patterns[j]
                for c in self._k_subsets(pattern1.union(pattern2), len(pattern1)+1):
                    if len(c) > 0 and str(c) not in already_gen:
                        already_gen.add(str(c))
                        candidate.append(c)
        return candidate

    def generalized_apriori_gen(self, prevalent_patterns):
        def join(prevalent_patterns):
            # cross support candidate
            pruned_candidate = []
            for c in candidate:
                all_sub_c = [c - {i} for i in c]
                for sub_c in all_sub_c:
                    for prevalent_pattern in prevalent_patterns:
                        sub_c.issubset(prevalent_pattern)
            return pruned_candidate
        def prune1(candidate):
            pruned_candidate = []
            for c in candidate:
                min_supp = min([self.supp({i}) for i in c])
                max_supp = max([self.supp({i}) for i in c])
                if min_supp / max_supp < self._hconf_thresh:
                    pruned_candidate.append(c)
            return pruned_candidate
        def prune2(candidate):
            pruned_candidate = []
            return pruned_candidate
        # join step
        candidate = []
        # prune step
        candidate = prune1(candidate)
        candidate = prune2(candidate)
        candidate = prune3(candidate)
        return candidate

    def find(self, transactions):
        self.set_transections(transactions)
        # find
        candidate = [{i} for i in self._I if self.supp({i}) > self._supp_thresh]
        hyperclique_patterns = candidate
        for k in range(2, len(self._I)):
            #candidate = self.generalized_apriori_gen(candidate)
            candidate = self.gen_candidate(candidate)
            candidate = [c for c in candidate if self.supp(c) > self._supp_thresh]
            candidate = [c for c in candidate if self.hconf(c) > self._hconf_thresh]
            if len(candidate) > 0:
                if self._verbose:
                    print('===== Level {} ====='.format(k))
                    for p in candidate:
                        print('{}, supp:{}, conf:{}'.format(p, miner.supp(p), miner.hconf(p)))
                for i in reversed(range(len(hyperclique_patterns))):
                    for c in candidate:
                        if hyperclique_patterns[i].issubset(c):
                            del hyperclique_patterns[i]
                            break
                hyperclique_patterns += candidate
            else:
                break
        return hyperclique_patterns


transections = [
    {1,2},
    {1,2},
    {1,3,4},
    {1,2},
    {1,2},
    {1,2},
    {1,2,3,4,5},
    {1,2},
    {1,2},
    {2,3,5},
]

miner = HypercliqueMiner(hconf_thresh=0.3, supp_thresh=0.0, verbose=True)
hyperclique_patterns = miner.find(transections)
print(hyperclique_patterns)


