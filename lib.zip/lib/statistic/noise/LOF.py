from __future__ import print_function

def sklearn_LocalOutlierFactor(X, verbose=False, **parms):  
    """LocalOutlierFactor algorithm from sklearn with parms wrapper.
    Document: http://scikit-learn.org/stable/modules/generated/sklearn.cluster.estimate_bandwidth.html
    
    Args:
        X (2D np.array): Vectors.
        parms (dict): Parameters dictionary.
                      parms['contamination'] (float, defalut=0.1)
    
    Returns:
        labels (np.array): Vectors. -1 means noise
    
    """
    
    try:
        from sklearn.neighbors import LocalOutlierFactor
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')
    
    if verbose:
        print('Run LocalOutlierFactor on {} data'.format(len(X)))
    
    # run lof
    lof = LocalOutlierFactor(**parms)
    labels = lof.fit_predict(X)
    
    return labels