from __future__ import print_function

def load_vector(word_vector_file, seperator=' ', verbose=False):
    """Load vector from file

    The format for a file is:
        line1:word1 v1 v2 v3 ... \n
        line2:word2 v1 v2 v3 ... \n
        ...

    Args:
        word_vector_file (str): File path for word vector.
        seperator (str): Seperate the word and feature in line.

    Retruns:
        words (list): Words for vector.
        X (2D np.array): Vectors.

    """
    import numpy as np

    if verbose:
        print("Loading vector from file: {}".format(word_vector_file), end=", ")

    words = [line.strip().split()[0] for line in open(word_vector_file, 'r')]
    X = [line.strip().split(seperator)[1:] for line in open(word_vector_file, 'r')]
    X = np.array(X, dtype=np.float32)

    if verbose:
        print('X shape: {}'.format(X.shape))
        
    return words, X

def l2_norm(X, verbose=False):
    """Normalize vectors by l2_norm

    Args:
        X (2D np.array): Vectors.

    Retruns:
        normalized_X (2D np.array): Normalized vectors.

    """
    try:
        from sklearn.preprocessing import Normalizer
    except ImportError as error:
        print(error)
        print('Try pip install sklearn')

    if verbose:
        print('Normalizing X to unit vectors')

    trf = Normalizer()
    normalized_X = trf.fit_transform(X)
    return normalized_X

def log_norm(X, verbose=False):
    """Normalize vectors by log

    Args:
        X (2D np.array): Vectors.

    Retruns:
        normalized_X (2D np.array): Normalized vectors.

    """
    import numpy as np

    if verbose:
        print('Normalizing X by log')

    normalized_X = np.log(np.abs(X) + 1) * np.sign(X)
    return normalized_X

def rm_labels(X, labels, labels_to_remove, verbose=False):
    labels_to_remove = set(labels_to_remove)
    removed_data = []
    reserved_data = []
    for i in range(len(labels)):
        if labels[i] in labels_to_remove:
            removed_data.append((X[i], labels[i]))
        else:
            reserved_data.append((X[i], labels[i]))
    if len(removed_data) > 0:
        removed_X, removed_labels = zip(*removed_data)
    else:
        removed_X, removed_labels = [], []
    if len(reserved_data) > 0:
        reserved_X, reserved_labels = zip(*reserved_data)
    else:
        reserved_X, reserved_labels = [], []
    if verbose:
        print('Remove {} data from {} by labels {}, reserve {}').format(len(removed_X), len(X), labels_to_remove, len(reserved_X))
    return reserved_X, reserved_labels, removed_X, removed_labels

def output_cluster(labels, id2name=None, folder='output_cluster', readme_list=None, verbose=False):
    if verbose:
        print('Output cluster, labels {}, folder = {}'.format(len(labels), folder))
    import os
    import codecs
    if not id2name:
        ids = range(len(labels))
        names = map(str, range(len(labels)))
        id2name = dict(zip(ids, names))
    if not os.path.exists(folder):
        os.makedirs(folder)
    clusters = dict()
    # clusters
    for id_, label in enumerate(labels):
        name = str(id2name[id_])
        if label not in clusters:
            clusters[label] = [name]
        else:
            clusters[label].append(name)
    # output cluster size
    with codecs.open(os.path.join(folder, 'cluster_size.txt'), 'w', encoding='utf-8', errors='ignore') as f:
        num_cluster = len(set(labels)) - (1 if -1 in labels else 0)
        f.write('number of clusters {}\n'.format(num_cluster))
        for cluster_num, name_list in clusters.items():
            f.write('size of cluster{}: {}\n'.format(cluster_num, len(name_list)))
    # output entities
    for cluster_num, name_list in clusters.items():
        fname = 'cluster{}.txt'.format(cluster_num)
        with codecs.open(os.path.join(folder, fname), 'w', encoding='utf-8', errors='ignore') as f:
            f.write('\n'.join(name_list))
    # output readme
    if readme_list:
        with codecs.open(os.path.join(folder, 'Readme.md'), 'w', encoding='utf-8', errors='ignore') as f:
            f.write('\n'.join(readme_list))




