def sklearn_Agglomerative(X, **parms):
    """Agglomerative algorithm from sklearn with parms wrapper.
    Document: http://scikit-learn.org/stable/modules/generated/sklearn.cluster.estimate_bandwidth.html

    Args:
        X (2D np.array): Vectors.
         parms (dict): Parameters dictionary.
                       parms['n_clusters'] (float, optional, default 2)
                       parms['linkage'] (str, optional, default: “ward”)

    Returns:
        labels (list): Clustering results.
        n_clusters (int): Number of clusters.

    """
    try:
        from sklearn.cluster import AgglomerativeClustering
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')
    n_clusters = parms['n_clusters']
    agg = AgglomerativeClustering(**parms).fit(X)
    labels = agg.labels_
    return labels, n_clusters