def sklearn_Birch(X, **parms):
    """Birch algorithm from sklearn with parms wrapper.

    Args:
        X (2D np.array): Vectors.
         parms (dict): Parameters dictionary.
                       parms['n_clusters'] (int, required)

    Returns:
        labels (list): Clustering results.
        n_clusters (int): Number of clusters.

    """
    try:
        from sklearn.cluster import Birch
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')
    n_clusters = parms['n_clusters']
    birch = Birch(**parms).fit(X)
    labels = birch.labels_
    return labels, n_clusters