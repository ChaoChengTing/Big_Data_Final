from .KMeans import sklearn_KMeans
from .DBSCAN import sklearn_DBSCAN
from .OPTICS import pyclustering_OPTICS
from .HDBSCAN import hdbscan_HDBSCAN
from .MeanShift import sklearn_MeanShift
from .MiniBatchKMeans import sklearn_MiniBatchKMeans
from .Birch import sklearn_Birch
from .Agglomerative import sklearn_Agglomerative
from .Spectral import sklearn_Spectral

from .GMM import sklearn_GMM

valid_algs = dict({
	'sklearn_KMeans': sklearn_KMeans,
	'sklearn_DBSCAN': sklearn_DBSCAN,
	'pyclustering_OPTICS': pyclustering_OPTICS,
	'hdbscan_HDBSCAN': hdbscan_HDBSCAN,
	'sklearn_MeanShift': sklearn_MeanShift,
	'sklearn_MiniBatchKMeans': sklearn_MiniBatchKMeans,
	'sklearn_Birch': sklearn_Birch,
	'sklearn_Agglomerative': sklearn_Agglomerative,
	'sklearn_Spectral': sklearn_Spectral,
	'sklearn_GMM': sklearn_GMM
})

def clustering(X, alg, **parms):
	assert alg in valid_algs, 'Valid algs are {}'.format(valid_algs.keys())
	alg_fn = valid_algs[alg]
	labels, n_clusters = alg_fn(X, **parms)
	return labels, n_clusters

