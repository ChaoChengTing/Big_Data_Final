def hdbscan_HDBSCAN(X, **parms):
    """HDBSCAN algorithm from hdbscan with parms wrapper.
    Document: http://hdbscan.readthedocs.io/en/latest/parameter_selection.html

    Args:
        X (2D np.array): Vectors.
         parms (dict): Parameters dictionary.
                       parms['min_cluster_size'] (int, optional)

    Returns:
        labels (list): Clustering results.
        n_clusters (int): Number of clusters.

    """
    try:
        from hdbscan import HDBSCAN
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install hdbscan')
    hdb = HDBSCAN(**parms).fit(X)
    labels = hdb.labels_
    labels = labels.astype(int).tolist()
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    return labels, n_clusters