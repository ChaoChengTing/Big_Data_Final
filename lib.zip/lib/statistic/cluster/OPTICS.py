def pyclustering_OPTICS(X, **parms):
    """OPTICS algorithm from pyclustering with parms wrapper.

    Args:
        X (2D np.array): Vectors.
         parms (dict): Parameters dictionary.
                       parms['eps'] (float, requires)
                       parms['minpts'] (int, requires)

    Returns:
        labels (list): Clustering results.
        n_clusters (int): Number of clusters.

    """
    try:
        from pyclustering.cluster.optics import optics
        from pyclustering.utils import timedcall
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install pyclustering')
    optics_instance = optics(X, **parms)
    (ticks, _) = timedcall(optics_instance.process)

    clusters = optics_instance.get_clusters();
    noise = optics_instance.get_noise()

    labels = [None] * len(X)
    for k, cluster in enumerate(clusters):
        for sample_id in cluster:
            labels[sample_id] = k
    for sample_id in noise:
        labels[sample_id] = -1

    n_clusters = len(clusters)
    return labels, n_clusters