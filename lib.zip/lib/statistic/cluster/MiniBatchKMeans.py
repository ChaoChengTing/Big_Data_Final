def sklearn_MiniBatchKMeans(X, **parms):
    """KMeans algorithm from sklearn with parms wrapper.
    Document: http://scikit-learn.org/stable/modules/generated/sklearn.cluster.estimate_bandwidth.html

    Args:
        X (2D np.array): Vectors.
         parms (dict): Parameters dictionary.
                       parms['n_clusters'] (int, required)

    Returns:
        labels (list): Clustering results.
        n_clusters (int): Number of clusters.

    """
    try:
        from sklearn.cluster import MiniBatchKMeans
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')
    n_clusters = parms['n_clusters']
    mbkm = MiniBatchKMeans(**parms).fit(X)
    labels = mbkm.labels_
    return labels, n_clusters