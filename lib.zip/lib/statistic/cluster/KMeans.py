def sklearn_KMeans(X, **parms):
    """KMeans algorithm from sklearn with parms wrapper.

    Args:
        X (2D np.array): Vectors.
         parms (dict): Parameters dictionary.
                       parms['n_clusters'] (int, required)

    Returns:
        labels (list): Clustering results.
        n_clusters (int): Number of clusters.

    """
    try:
        from sklearn.cluster import KMeans
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')
    n_clusters = parms['n_clusters']
    km = KMeans(**parms).fit(X)
    labels = km.labels_
    return labels, n_clusters