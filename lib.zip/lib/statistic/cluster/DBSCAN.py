def sklearn_DBSCAN(X, **parms):
    """DBSCAN algorithm from sklearn with parms wrapper.

    Args:
        X (2D np.array): Vectors.
         parms (dict): Parameters dictionary.
                       parms['eps'] (float, optional)
                       parms['min_samples'] (int, optional)
                       parms['metric'] (str or callable, optional)

    Returns:
        labels (list): Clustering results.
        n_clusters (int): Number of clusters.

    """
    try:
        from sklearn.cluster import DBSCAN
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')

    db = DBSCAN(**parms).fit(X)
    labels = db.labels_
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    return labels, n_clusters