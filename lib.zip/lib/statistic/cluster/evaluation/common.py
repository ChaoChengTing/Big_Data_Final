from .matrics import silhouette
from .matrics import calinski
from .matrics import davis_bouldin
from .matrics import dunn

valid_matrics_fn = dict({
    'silhouette': silhouette, 
    'calinski': calinski, 
    'davis_bouldin': davis_bouldin, 
    'dunn': dunn
})

def evaluation(X, labels, matrics, verbose=False):
    matrics = list(matrics)
    assert all(m in valid_matrics_fn for m in matrics), 'Valid matrics are {}'.format(valid_matrics_fn.keys())
    results = []
    for matrix in matrics:
        evaluation_fn = valid_matrics_fn[matrix]
        try:
            value = evaluation_fn(X, labels)
        except Exception as e:
            if verbose:
                print(e)
            value = float('nan')
        results.append(value)
    return results
