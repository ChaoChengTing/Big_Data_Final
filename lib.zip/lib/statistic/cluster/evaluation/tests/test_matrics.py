from mylib.statistic.cluster import evaluation 

X = [[0,0,0],[1,0,0], 
        [2,2,2],[2,2,2], 
        [4,4,4],[4,4,5]]
labels = [0,0,1,1,2,2]

def test_silhouette():
    silhouette = evaluation.silhouette(X, labels)

def test_calinski():
    calinski = evaluation.calinski(X, labels)

def test_davis_bouldin():
    db = evaluation.davis_bouldin(X, labels)

def test_dunn():
    dunn = evaluation.dunn(X, labels)

if __name__ == '__main__':
    test_silhouette()
    test_calinski()
    test_davis_bouldin()
    test_dunn()
