def silhouette(X, labels):
    """higher value is better, value from -1 to 1"""
    from sklearn import metrics
    silhouette_avg = metrics.silhouette_score(X, labels)
    return silhouette_avg

def calinski(X, labels):
    """higher value is better, value from 0 to INF"""
    from sklearn import metrics
    calinski_score = metrics.calinski_harabaz_score(X, labels)
    return calinski_score

def davis_bouldin(X, labels):
    """lower value is better, value from 0 to INF"""
    import numpy as np
    from scipy.spatial.distance import euclidean
    X = np.array(X)
    labels = np.array(labels)
    n_cluster = len(set(labels))
    cluster_k = [X[labels == k] for k in set(labels)]
    centroids = [np.mean(k, axis=0) for k in cluster_k]
    variances = [np.mean([euclidean(p, centroids[i]) for p in k]) for i, k in enumerate(cluster_k)]
    db = []
    for i in range(n_cluster):
        for j in range(n_cluster):
            if j != i:
                db.append((variances[i] + variances[j]) / euclidean(centroids[i], centroids[j]))
    return (np.max(db) / n_cluster)

def dunn(X, labels):
    """higher value is better, value from 0 to INF"""
    import numpy as np
    from sklearn.metrics.pairwise import euclidean_distances
    def inter_distance(cluster1_points, cluster2_points):
        return np.min(euclidean_distances(cluster1_points, cluster2_points))
    def intra_distance(cluster_points):
        return np.max(euclidean_distances(cluster_points))
    X = np.array(X)
    labels = np.array(labels)
    n_cluster = len(set(labels))
    cluster_k = [X[labels == k] for k in set(labels)]
    min_inter_dist = min([inter_distance(cluster_k[i], cluster_k[j]) for i in range(n_cluster-1) for j in range(i+1, n_cluster)])
    max_intra_dist = max([intra_distance(cluster_points) for cluster_points in cluster_k])
    D = min_inter_dist / max_intra_dist
    return D

def cluster_size(labels):
    labels = list(labels)
    size_dict = {cluster: labels.count(cluster) for cluster in set(labels)}
    return size_dict

def top_cluster_size(labels, top_n=5):
    assert top_n > 0
    size_dict = cluster_size(labels)
    sorted_size = sorted(size_dict.values(), reverse=True)
    top_size = sorted_size[:top_n]
    return top_size

def cluster_size_variance(labels):
    import numpy as np
    size_list = list(cluster_size(labels).values())
    var = np.var(size_list)
    return var