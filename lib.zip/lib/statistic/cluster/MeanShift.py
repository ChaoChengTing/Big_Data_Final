def sklearn_MeanShift(X, **parms):
    """MeanShift algorithm from sklearn with parms wrapper.
    Document: http://scikit-learn.org/stable/modules/generated/sklearn.cluster.estimate_bandwidth.html

    Args:
        X (2D np.array): Vectors.
         parms (dict): Parameters dictionary.
                       parms['quantile'] (float, optional)
                       parms['n_samples'] (int, optional)

    Returns:
        labels (list): Clustering results.
        n_clusters (int): Number of clusters.

    """
    try:
        from sklearn.cluster import MeanShift, estimate_bandwidth
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')
    bandwidth = estimate_bandwidth(X, **parms)
    ms = MeanShift(bandwidth=bandwidth, bin_seeding=True).fit(X)
    labels = ms.labels_
    n_clusters = len(set(labels))
    return labels, n_clusters