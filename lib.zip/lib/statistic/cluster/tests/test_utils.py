import os
script_path = os.path.dirname(os.path.abspath(__file__))
test_file = os.path.join(script_path, 'data', 'test_vectors.txt')

def test_load_vector():
    from mylib.statistic.cluster.utils import load_vector
    word, X = load_vector(test_file)

def test_l2_norm():
    from mylib.statistic.cluster.utils import load_vector, l2_norm
    word, X = load_vector(test_file)
    normalized_X = l2_norm(X)

if __name__ == '__main__':
    test_load_vector()
    test_l2_norm()