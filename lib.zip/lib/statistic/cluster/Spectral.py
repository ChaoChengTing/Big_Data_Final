def sklearn_Spectral(X, **parms):
    """Spectral algorithm from sklearn with parms wrapper.
    Document: http://scikit-learn.org/stable/modules/generated/sklearn.cluster.estimate_bandwidth.html

    Args:
        X (2D np.array): Vectors.
         parms (dict): Parameters dictionary.
                       parms['n_clusters'] (float, optional, default 2)

    Returns:
        labels (list): Clustering results.
        n_clusters (int): Number of clusters.

    """
    try:
        from sklearn.cluster import SpectralClustering
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')
    n_clusters = parms['n_clusters']
    agg = SpectralClustering(**parms).fit(X)
    labels = agg.labels_
    return labels, n_clusters