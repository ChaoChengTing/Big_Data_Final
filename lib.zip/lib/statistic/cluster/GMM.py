def sklearn_GMM(X, **parms):
    """GMM algorithm from sklearn with parms wrapper.

    Args:
        X (2D np.array): Vectors.
         parms (dict): Parameters dictionary.
                       parms['n_components'] (int, optional, default 1)

    Returns:
        labels (list): Clustering results.
        n_clusters (int): Number of clusters.

    """
    try:
        from sklearn.mixture import GaussianMixture
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')
    gmm = GaussianMixture(**parms).fit(X)
    labels = gmm.predict(X)
    n_clusters = len(set(labels))
    return labels, n_clusters