from __future__ import print_function

def sklearn_LocallyLinearEmbedding(X, verbose=False, **parms):  
    """LLE algorithm from sklearn with parms wrapper.
    Document: http://scikit-learn.org/stable/modules/generated/sklearn.cluster.estimate_bandwidth.html

    Args:
        X (2D np.array): Vectors.
        parms (dict): Parameters dictionary.
                      parms['n_components'] (int, required)
                      parms['n_neighbors'] (int, defalut is 5)
                      parms['method'] (str, defalut is standard)

    Returns:
        transformed_word_vectors (2D np.array): Vectors.

    """
    assert parms.get('n_components') is not None, "parms['n_components'] is required"
    n_components = parms.get('n_components')
    method = parms.get('method', 'standard')

    try:
        from sklearn.manifold import LocallyLinearEmbedding
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')

    if verbose:
        print('Run LocallyLinearEmbedding on {} data, method = {}, n_components = {}'.format(len(X), method, n_components))

    # check n_neighbors if method is hessian
    if method == 'hessian':
        if parms.get('n_neighbors', 5) < (n_components * (n_components + 3) / 2):
            parms['n_neighbors'] = int(n_components * (n_components + 3) / 2) + 1
            if verbose:
                print('Parms n_neighbors should greater than [n_components * (n_components + 3) / 2], auto set to {}'.format(parms['n_neighbors']))

    # run lle
    lle = LocallyLinearEmbedding(**parms)
    transformed_word_vectors = lle.fit_transform(X)
    
    return transformed_word_vectors