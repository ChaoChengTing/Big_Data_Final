from .pca import sklearn_PCA
from .pca import sklearn_KernelPCA
from .tsne import sklearn_TSNE
from .lsa import sklearn_TruncatedSVD
from .sammon import sammon
from .LLE import sklearn_LocallyLinearEmbedding

valid_methods = dict({
    'sklearn_PCA': sklearn_PCA,
    'sklearn_TSNE': sklearn_TSNE,
    'sklearn_TruncatedSVD': sklearn_TruncatedSVD,
    'sklearn_KernelPCA': sklearn_KernelPCA,
    'sammon': sammon,
    'sklearn_LocallyLinearEmbedding': sklearn_LocallyLinearEmbedding
})

def dimension_reduction(X, reduction_method='sklearn_PCA', verbose=False, **parms):
    assert reduction_method in valid_methods, 'Valid methods are {}'.format(valid_methods.keys())
    method_fn = valid_methods[reduction_method]
    transformed_data = method_fn(X, verbose=verbose, **parms)
    return transformed_data

