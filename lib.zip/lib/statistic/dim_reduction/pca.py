from __future__ import print_function

def sklearn_PCA(X, verbose=False, **parms):
    """PCA algorithm from sklearn with parms wrapper.
    Document: http://scikit-learn.org/stable/modules/generated/sklearn.cluster.estimate_bandwidth.html

    Args:
        X (2D np.array): Vectors.
        parms (dict): Parameters dictionary.
                      parms['n_components'] (int, required)

    Returns:
        transformed_word_vectors (2D np.array): Vectors.

    """ 
    assert parms.get('n_components') is not None, "parms['n_components'] is required"
    try:
        from sklearn.decomposition import PCA
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')

    if verbose:  
        print('Run PCA on {} data, n_components = {}'.format(len(X), parms['n_components']), end=", ")

    pca = PCA(**parms).fit(X)
    retained_ratio = pca.explained_variance_ratio_.sum()

    if verbose:
        print('retained ratio: {}'.format(retained_ratio))

    transformed_word_vectors = pca.transform(X)
    return transformed_word_vectors


def sklearn_KernelPCA(X, verbose=False, **parms):
    """KernelPCA algorithm from sklearn with parms wrapper.
    Document: http://scikit-learn.org/stable/modules/generated/sklearn.cluster.estimate_bandwidth.html

    Args:
        X (2D np.array): Vectors.
        parms (dict): Parameters dictionary.
                      parms['n_components'] (int, required)

    Returns:
        transformed_word_vectors (2D np.array): Vectors.

    """ 
    assert parms.get('n_components') is not None, "parms['n_components'] is required"
    try:
        from sklearn.decomposition import KernelPCA
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')

    if verbose:  
        print('Run KernelPCA on {} data, n_components = {}'.format(len(X), parms['n_components']))

    kpca = KernelPCA(**parms)
    X_kpca = kpca.fit_transform(X)

    transformed_word_vectors = X_kpca
    return transformed_word_vectors