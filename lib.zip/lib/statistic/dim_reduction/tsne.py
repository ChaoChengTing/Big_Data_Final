from __future__ import print_function

def sklearn_TSNE(X, verbose=False, **parms):  
    """TSNE algorithm from sklearn with parms wrapper.
    Document: http://scikit-learn.org/stable/modules/generated/sklearn.cluster.estimate_bandwidth.html

    Args:
        X (2D np.array): Vectors.
        parms (dict): Parameters dictionary.
                      parms['n_components'] (int, required)

    Returns:
        transformed_word_vectors (2D np.array): Vectors.

    """
    assert parms.get('n_components') is not None, "parms['n_components'] is required"
    try:
        from sklearn.manifold import TSNE
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')

    if verbose:  
        print('Run T-SNE on {} data, n_components = {}, '.format(len(X), parms['n_components']))

    tsne = TSNE(**parms)
    transformed_word_vectors = tsne.fit_transform(X)
    
    return transformed_word_vectors