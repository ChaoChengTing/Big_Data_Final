from __future__ import print_function

def sklearn_TruncatedSVD(X, n_components, verbose=False, **parms):
    """TruncatedSVD algorithm from sklearn with parms wrapper.
    Document: http://scikit-learn.org/stable/modules/generated/sklearn.cluster.estimate_bandwidth.html

    Args:
        X (2D np.array): Vectors.
        parms (dict): Parameters dictionary.
                      parms['n_components'] (int, required)

    Returns:
        transformed_word_vectors (2D np.array): Vectors.

    """
    assert parms.get('n_components') is not None, "parms['n_components'] is required"
    try:
        from sklearn.decomposition import TruncatedSVD
    except ImportError as error:
        print(error)
        raise ImportError('Try pip install sklearn')

    if verbose:  
        print('Run TruncatedSVD on {} data, n_components = {}'.format(len(X), parms['n_components']), end=", ")

    svd = TruncatedSVD(**parms).fit(X)
    retained_ratio = tmp.explained_variance_ratio_.sum()

    if verbose:
        print('retained ratio: {}'.format(retained_ratio))
    
    transformed_word_vectors = svd.transform(word_vectors)
    return transformed_word_vectors