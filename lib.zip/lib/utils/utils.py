def parameter_grid(param_grid):
    from itertools import product
    for p in param_grid:
        items = sorted(p.items())
        if not items:
            yield {}
        else:
            keys, values = zip(*items)
            for v in product(*values):
                params = dict(zip(keys, v))
                yield params
